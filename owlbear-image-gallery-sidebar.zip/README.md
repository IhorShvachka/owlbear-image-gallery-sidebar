# Owlbear Image Gallery — compact sidebar MVP

This is a starter extension for Owlbear Rodeo using the official `@owlbear-rodeo/sdk`.

## Features
- Compact GM gallery panel
- Search by title, category, and description
- Image selection and preview
- Broadcast a selected image to participants in the room
- Open a compact viewer popover for each participant
- Hide the viewer for all participants

## Requirements
- Node.js LTS
- VS Code
- Owlbear Rodeo room where the extension is enabled

## Run locally
Open this folder in VS Code, then run:
```bash
npm install
npm run dev
```
In Owlbear Rodeo, add the local extension manifest:
`http://localhost:5173/manifest.json`

Keep the Vite terminal running while testing.

## Customize the catalog
Edit `src/catalog.ts`. Add or change objects with `id`, `title`, `category`, `url`, and optional `description`.

Use HTTPS image URLs that all participants can access. `localhost` URLs only work on your own device.

## Important MVP limitations
- This is starter code and has not been tested in your specific Owlbear room. Run `npm run build` and resolve any SDK/type errors before use.
- The player viewer uses a fixed anchor position (`left: 1180, top: 420`) because the current MVP does not calculate a responsive viewport edge. If it appears in the wrong place, tune these values in `src/background.ts`. This is an Owlbear popover, not a permanently docked native sidebar.
- The show/hide broadcast is ephemeral. A participant who joins after the image was shown will not automatically receive the current image.
- The MVP does not restrict controls to the GM; anyone who can open the extension may send show/hide messages. Add role/permission checks before using it in a public room.
- A player's close button closes the viewer on that participant's screen only. The GM's Hide button broadcasts the hide command to everyone.
- Use images you have permission to share with your players.
